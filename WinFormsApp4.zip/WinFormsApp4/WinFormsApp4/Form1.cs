using System;
using System.Windows.Forms;
using System.IO;
using Newtonsoft.Json;

namespace WinFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            string userName = textBox1.Text;

            string jsonText = File.ReadAllText("users.json");
            var users = JsonConvert.DeserializeObject<Dictionary<string, UserData>>(jsonText);

            if (users.ContainsKey(userName))
            {
                UserData user = users[userName];
                MessageBox.Show($"Welcome, {user.Name} {user.Surname}!");
            }
            else
            {
                MessageBox.Show("User not found.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (!File.Exists("users.json"))
            {
                string filePath = "users.json";
            }
            string userName = textBox1.Text;
            string userSurname = textBox2.Text;
            string userFatherName = textBox3.Text;
            string userCountry = textBox4.Text;
            string userCity = textBox5.Text;
            string userPhoneNumber = textBox6.Text;

            var users = new Dictionary<string, UserData>();

            if (File.Exists("users.json"))
            {
                string jsonText = File.ReadAllText("users.json");
                users = JsonConvert.DeserializeObject<Dictionary<string, UserData>>(jsonText);
            }

            var user = new UserData
            {
                Name = userName,
                Surname = userSurname,
                FatherName = userFatherName,
                Country = userCountry,
                City = userCity,
                PhoneNumber = userPhoneNumber
            };

            users[userName] = user;
            string json = JsonConvert.SerializeObject(users);

            File.WriteAllText("users.json", json);

            MessageBox.Show("User data saved!");
        }

    }

    public class UserData
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public string FatherName { get; set; }
        public string Country { get; set; }
        public string City { get; set; }
        public string PhoneNumber { get; set; }
    }

}